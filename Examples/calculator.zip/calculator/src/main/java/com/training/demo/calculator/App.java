package com.training.demo.calculator;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Calculator calc = new Calculator();

		System.out.println("Values: " + calc.calculate("45", "50"));

        System.out.println( "Hello World!" );
        
        Author author = new Author("Sathish", "Reddy", "sat@rad.com");
        
        Book headFirst = new Book(69, "Head First Java", author, 420.99);
        
        
    }
}
