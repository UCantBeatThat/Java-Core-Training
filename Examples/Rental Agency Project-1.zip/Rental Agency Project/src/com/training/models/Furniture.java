package com.training.models;

public class Furniture extends RentItem {

	public Furniture() {
		super();
	}

	public Furniture(String item_name, int quantity, double rate) {
		super(item_name, quantity, rate);
	}

}