package com.training.models;

public class Computer extends RentItem{

	public Computer() {
		super();
	}

	public Computer(String item_name, int quantity, double rate) {
		super(item_name, quantity, rate);
	}

}
